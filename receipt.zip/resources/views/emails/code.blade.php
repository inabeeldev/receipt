<!DOCTYPE html>
<html>
<head>
    <title>Receipt Management</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>Your code is : {{ $details['code'] }}</p>

    <p>Thank you</p>
</body>
</html>
