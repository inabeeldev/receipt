<!DOCTYPE html>
<html>
<head>
    <title>Receipt Management</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p>Your code is : <?php echo e($details['code']); ?></p>

    <p>Thank you</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\work1\receipt\resources\views/emails/code.blade.php ENDPATH**/ ?>